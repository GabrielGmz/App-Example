package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondScreen extends AppCompatActivity {

    private static final String TAG = "SecondScreen";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_main);
        Log.d(TAG, "OnCreate: Starting.");

        Button btnBack = (Button) findViewById(R.id.btnBack);

            btnBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, "onClick: clicked.");

                    Intent back = new Intent(SecondScreen.this, MainActivity.class);
                    startActivity(back);
                }
            });
        }
    public void onCalculateButtonClick(View view) {
        EditText kilometerField = findViewById(R.id.kilometers_edit_text);
        EditText fuelField = findViewById(R.id.gallons_edit_text);

        String kmValue = kilometerField.getText().toString();
        String gllnsValue = fuelField.getText().toString();

        Double kmNumber = Double.parseDouble(kmValue);
        Double gllnsNumber = Double.parseDouble(gllnsValue);

        TextView resultsField = findViewById(R.id.results_field);
        resultsField.setText(Double.toString(kmNumber / gllnsNumber) + " KM x GAL");
    }
    }